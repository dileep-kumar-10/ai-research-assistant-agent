"""
AI Research Assistant Agent
A small tool-using agent built with the OpenAI Responses API.
Tools: web search (Tavily) and a safe arithmetic calculator.
"""
import ast
import json
import os
import operator
import requests
from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
MODEL = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")
TAVILY_API_KEY = os.getenv("TAVILY_API_KEY")

SYSTEM_PROMPT = """
You are a concise research assistant. Help users answer questions accurately.
Use web_search for current facts and cite the URLs returned by the tool.
Use calculator for arithmetic. If a tool is unnecessary, answer directly.
Be transparent about uncertainty and never invent sources.
"""

def web_search(query: str) -> str:
    """Search the web using the Tavily Search API."""
    if not TAVILY_API_KEY:
        return "Web search is not configured. Add TAVILY_API_KEY to your .env file."
    response = requests.post(
        "https://api.tavily.com/search",
        json={"api_key": TAVILY_API_KEY, "query": query, "max_results": 5},
        timeout=20,
    )
    response.raise_for_status()
    results = response.json().get("results", [])
    return json.dumps([
        {"title": r.get("title"), "url": r.get("url"), "content": r.get("content")}
        for r in results
    ], ensure_ascii=False)

_ALLOWED_BINOPS = {
    ast.Add: operator.add, ast.Sub: operator.sub,
    ast.Mult: operator.mul, ast.Div: operator.truediv,
    ast.Pow: operator.pow, ast.Mod: operator.mod,
}
_ALLOWED_UNARYOPS = {ast.UAdd: operator.pos, ast.USub: operator.neg}

def _safe_eval(node):
    if isinstance(node, ast.Expression):
        return _safe_eval(node.body)
    if isinstance(node, ast.Constant) and type(node.value) in (int, float):
        return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in _ALLOWED_BINOPS:
        return _ALLOWED_BINOPS[type(node.op)](_safe_eval(node.left), _safe_eval(node.right))
    if isinstance(node, ast.UnaryOp) and type(node.op) in _ALLOWED_UNARYOPS:
        return _ALLOWED_UNARYOPS[type(node.op)](_safe_eval(node.operand))
    raise ValueError("Only basic arithmetic expressions are allowed.")

def calculator(expression: str) -> str:
    """Safely evaluate a basic arithmetic expression."""
    if len(expression) > 100:
        raise ValueError("Expression is too long.")
    tree = ast.parse(expression, mode="eval")
    return str(_safe_eval(tree))

TOOLS = [
    {
        "type": "function",
        "name": "web_search",
        "description": "Search the web for current information. Returns titles, snippets, and URLs.",
        "parameters": {
            "type": "object",
            "properties": {"query": {"type": "string"}},
            "required": ["query"],
            "additionalProperties": False,
        },
        "strict": True,
    },
    {
        "type": "function",
        "name": "calculator",
        "description": "Calculate a basic arithmetic expression, such as (25 * 4) / 3.",
        "parameters": {
            "type": "object",
            "properties": {"expression": {"type": "string"}},
            "required": ["expression"],
            "additionalProperties": False,
        },
        "strict": True,
    },
]

def run_agent(question: str) -> str:
    """Run the agent loop until the model returns a final answer."""
    response = client.responses.create(
        model=MODEL,
        instructions=SYSTEM_PROMPT,
        input=question,
        tools=TOOLS,
    )

    # Execute requested tools and pass their outputs back to the model.
    while True:
        calls = [item for item in response.output if item.type == "function_call"]
        if not calls:
            return response.output_text

        outputs = []
        for call in calls:
            args = json.loads(call.arguments)
            try:
                if call.name == "web_search":
                    result = web_search(args["query"])
                elif call.name == "calculator":
                    result = calculator(args["expression"])
                else:
                    result = "Unknown tool."
            except Exception as exc:
                result = f"Tool error: {exc}"
            outputs.append({"type": "function_call_output", "call_id": call.call_id, "output": str(result)})

        response = client.responses.create(
            model=MODEL,
            previous_response_id=response.id,
            input=outputs,
            tools=TOOLS,
        )

def main():
    if not os.getenv("OPENAI_API_KEY"):
        raise SystemExit("Set OPENAI_API_KEY in your .env file. See README.md.")
    print("\nAI Research Assistant Agent")
    print("Ask a question, or type 'exit' to quit.\n")
    while True:
        question = input("You: ").strip()
        if question.lower() in {"exit", "quit"}:
            print("Goodbye!")
            break
        if not question:
            continue
        try:
            print("\nAgent:", run_agent(question), "\n")
        except Exception as exc:
            print(f"\nError: {exc}\n")

if __name__ == "__main__":
    main()
