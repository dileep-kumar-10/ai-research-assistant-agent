# AI Research Assistant Agent

A beginner-friendly, tool-using AI agent built with Python and the OpenAI Responses API. It can decide when to search the web or calculate an expression, execute the selected tool, and use the result to answer the user.

## Features
- LLM-driven tool selection (not just a fixed sequence of prompts)
- Web search through the Tavily Search API
- Safe arithmetic calculator (uses Python AST; does not use `eval`)
- Multi-step tool loop
- Environment-variable configuration

## Architecture
1. User asks a question.
2. The model decides whether a tool is needed.
3. Python executes `web_search` or `calculator`.
4. Tool output is sent back to the model.
5. The model returns a final answer.

## Setup

Requires Python 3.10+.

```bash
git clone https://github.com/YOUR-USERNAME/ai-research-assistant-agent.git
cd ai-research-assistant-agent
python -m venv .venv
```

Activate the environment:

**Windows**
```bash
.venv\Scripts\activate
```

**macOS / Linux**
```bash
source .venv/bin/activate
```

Install dependencies and configure keys:

```bash
pip install -r requirements.txt
cp .env.example .env
```

Open `.env` and add your OpenAI API key. Add a Tavily API key to enable web search. The calculator works without Tavily.

Run:

```bash
python main.py
```

## Example prompts
- `What is the latest news about Python 3.14?` (uses web search)
- `Calculate (125 * 18) / 6` (uses calculator)
- `Explain what an AI agent is in simple terms.` (answers directly)

## API keys
- OpenAI API key: https://platform.openai.com/api-keys
- Tavily API key: https://app.tavily.com/

Never commit your `.env` file or expose API keys in screenshots or public repositories.

## Tech stack
Python, OpenAI Responses API, function/tool calling, Tavily Search API, python-dotenv.

## Important note
This project requires your own API keys and may incur API usage charges. It is a learning/demo project, not a production research or fact-verification system. Always verify important information from original sources.

## License
MIT
